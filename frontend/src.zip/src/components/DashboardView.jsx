import React, { useState, useEffect } from 'react';
import { ClipboardList, FileText, HeartPulse, Sparkles, BookOpen, Award, ArrowRight, ChevronRight } from 'lucide-react';
import { t } from '../i18n';
import HealthScoreWidget from './HealthScoreWidget';

export default function DashboardView({ setActiveView, backendUrl, lang = 'en' }) {
  const [userName, setUserName] = useState(() => localStorage.getItem('user_name') || 'Guest Patient');
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(userName);
  const [healthTip, setHealthTip] = useState('');

  useEffect(() => {
    const tips = t('tips', lang);
    setHealthTip(tips[Math.floor(Math.random() * tips.length)]);
  }, [lang]);

  const handleSaveName = () => {
    const trimmed = nameInput.trim();
    if (trimmed) {
      setUserName(trimmed);
      localStorage.setItem('user_name', trimmed);
    }
    setIsEditingName(false);
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', width: '100%' }}>
      {/* Welcome Header */}
      <div className="card span-12" style={{ marginBottom: '2rem', background: 'linear-gradient(135deg, var(--bg-secondary) 0%, rgba(139, 92, 246, 0.1) 100%)', borderLeft: '4px solid var(--accent)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>
              {t('welcomeBack', lang)}
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: '0.25rem' }}>
              {isEditingName ? (
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input
                    type="text"
                    className="form-control"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSaveName()}
                    style={{ padding: '4px 10px', fontSize: '1.25rem', width: '200px' }}
                  />
                  <button className="btn btn-primary" style={{ padding: '4px 12px', fontSize: '0.85rem' }} onClick={handleSaveName}>
                    {t('save', lang)}
                  </button>
                </div>
              ) : (
                <>
                  <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', fontWeight: '800' }}>
                    {t('dashboardGreeting', lang)}, {userName}!
                  </h2>
                  <button
                    style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontSize: '0.85rem', textDecoration: 'underline' }}
                    onClick={() => { setNameInput(userName); setIsEditingName(true); }}
                  >
                    {t('editName', lang)}
                  </button>
                </>
              )}
            </div>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginTop: '0.25rem' }}>
              {t('dashboardSubtitle', lang)}
            </p>
          </div>

          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <Award size={36} color="var(--accent)" />
            <div style={{ fontSize: '0.8rem' }}>
              <span style={{ color: 'var(--text-muted)', display: 'block' }}>{t('platformSubmission', lang)}</span>
              <span style={{ color: 'var(--text-primary)', fontWeight: '600' }}>{t('platformOrg', lang)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main widgets grid */}
      <div className="dashboard-grid">

        {/* ── Health Score Widget ── */}
        <HealthScoreWidget setActiveView={setActiveView} lang={lang} />

        {/* Quick action: Risk Assessment */}
        <div className="card span-4" style={{ display: 'flex', flexDirection: 'column', minHeight: '240px' }}>
          <div style={{ width: '42px', height: '42px', borderRadius: '10px', backgroundColor: 'hsla(263, 67%, 50%, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary-hover)', marginBottom: '1.25rem' }}>
            <ClipboardList size={22} />
          </div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.15rem', fontWeight: '700', marginBottom: '0.5rem' }}>
            {t('riskScreening', lang)}
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', flexGrow: 1 }}>
            {t('riskScreeningDesc', lang)}
          </p>
          <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem', padding: '0.5rem' }} onClick={() => setActiveView('risk-assessment')}>
            {t('startScreening', lang)} <ArrowRight size={14} />
          </button>
        </div>

        {/* Quick action: Report Explainer */}
        <div className="card span-4" style={{ display: 'flex', flexDirection: 'column', minHeight: '240px' }}>
          <div style={{ width: '42px', height: '42px', borderRadius: '10px', backgroundColor: 'hsla(335, 78%, 62%, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)', marginBottom: '1.25rem' }}>
            <FileText size={22} />
          </div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.15rem', fontWeight: '700', marginBottom: '0.5rem' }}>
            {t('reportExplainer', lang)}
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', flexGrow: 1 }}>
            {t('reportExplainerDesc', lang)}
          </p>
          <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem', padding: '0.5rem' }} onClick={() => setActiveView('report-explainer')}>
            {t('explainReport', lang)} <ArrowRight size={14} />
          </button>
        </div>

        {/* Tip of the day — span-8 */}
        <div className="card span-8" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', borderLeft: '4px solid var(--primary)' }}>
          <div style={{ padding: '0.75rem', borderRadius: '12px', backgroundColor: 'hsla(263, 67%, 50%, 0.1)', color: 'var(--primary-hover)', flexShrink: 0 }}>
            <Sparkles size={28} />
          </div>
          <div>
            <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: '700', color: 'var(--text-primary)', marginBottom: '0.25rem' }}>
              {t('dailyTip', lang)} <span style={{ color: 'var(--text-muted)', fontWeight: 400, fontSize: '0.85rem' }}>({t('tipLabel', lang)})</span>
            </h4>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.88rem', fontStyle: 'italic', lineHeight: '1.5' }}>
              "{healthTip}"
            </p>
          </div>
        </div>

        {/* Recovery Assistant — span-4 */}
        <div className="card span-4" style={{ display: 'flex', flexDirection: 'column', minHeight: '200px' }}>
          <div style={{ width: '42px', height: '42px', borderRadius: '10px', backgroundColor: 'hsla(145, 63%, 45%, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--success)', marginBottom: '1.25rem' }}>
            <HeartPulse size={22} />
          </div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.15rem', fontWeight: '700', marginBottom: '0.5rem' }}>
            {t('recoveryAssistant', lang)}
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', flexGrow: 1 }}>
            {t('recoveryAssistantDesc', lang)}
          </p>
          <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem', padding: '0.5rem' }} onClick={() => setActiveView('recovery-assistant')}>
            {t('trackRecovery', lang)} <ArrowRight size={14} />
          </button>
        </div>

        {/* Health Library shortcut — span-4 */}
        <div className="card span-4" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }} onClick={() => setActiveView('health-library')}>
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
            <div style={{ padding: '8px', borderRadius: '8px', backgroundColor: 'var(--bg-tertiary)', color: 'var(--accent)' }}>
              <BookOpen size={20} />
            </div>
            <div>
              <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '0.95rem', fontWeight: '700' }}>
                {t('healthLibrary', lang)}
              </h4>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {t('browseLibrary', lang)}
              </span>
            </div>
          </div>
          <ChevronRight size={16} color="var(--text-muted)" />
        </div>
      </div>

      {/* Disclaimer */}
      <div className="disclaimer-box" style={{ marginTop: '2rem' }}>
        {t('disclaimer', lang)}
      </div>
    </div>
  );
}
